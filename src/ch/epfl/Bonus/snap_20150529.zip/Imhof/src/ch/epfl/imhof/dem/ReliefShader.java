package ch.epfl.imhof.dem;

import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.util.function.Function;

import ch.epfl.imhof.Vector3;
import ch.epfl.imhof.geometry.Point;
import ch.epfl.imhof.painting.Color;
import ch.epfl.imhof.projection.Projection;

/**
 * Classe creant une bufferedImage qui represente le terrain en 3D
 * 
 * @author Hugo Hueber (246095)
 * @author Maxime Pisa (247650)
 */
public final class ReliefShader {
    private final Projection projection;
    private final DigitalElevationModel dem;
    private final Vector3 direction;

    /**
     * Construit un objet ReliefShader
     * 
     * @param projection
     *            Une projection quelconque (CH1903 dans notre cas)
     * @param dem
     *            Un objet qui represente un modele d'elevation
     * @param direction
     *            Le vecteur utilise pour la creation des ombres
     */
    public ReliefShader(Projection projection, DigitalElevationModel dem,
            Vector3 direction) {
        this.projection = projection;
        this.dem = dem;
        this.direction = direction.normalized();
    }

    /**
     * Floutage
     * 
     * @param bg
     *            Le point bas-gauche en coordonee du plan
     * @param hd
     *            Le point bas-gauche en coordonee du plan
     * @param width
     *            La largeur de l'image
     * @param height
     *            La hauteur de l'image
     * @param rayon
     *            Le rayon de floutage
     * @return Une image de type BufferedImage qui represente le modele du
     *         terrain
     */
    public BufferedImage shadedRelief(Point bg, Point hd, int width,
            int height, double rayon) {

        BufferedImage b = new BufferedImage(width, height,
                BufferedImage.TYPE_INT_ARGB);

        Function<Point, Point> coordChange;

        if (rayon == 0) {
            coordChange = Point.alignedCoordinateChange(new Point(0, height),
                    bg, new Point(width, 0), hd);
            b = rawRelief(width, height, coordChange);
        } else {
            float[] r = getKernel(rayon);
            int a = r.length / 2;
            // Determine le tampon
            coordChange = Point.alignedCoordinateChange(
                    new Point(a, height + a), bg, new Point(width + a, a), hd);

            b = rawRelief(width + 2 * a, height + 2 * a, coordChange);
            b = blur(b, r);
            b = b.getSubimage(a, a, width, height);
        }
        return b;

    }

    /**
     * 
     * @param width
     *            Largeur
     * @param height
     *            Hauteur
     * @param coordChange
     *            Chngement de coordonnees
     * @return Le relief brut
     */
    private BufferedImage rawRelief(int width, int height,
            Function<Point, Point> coordChange) {

        BufferedImage b = new BufferedImage(width, height,
                BufferedImage.TYPE_INT_ARGB);

        for (int i = 0; i < height; ++i) {
            for (int j = 0; j < width; ++j) {

                Vector3 normal = this.dem.normalAt(
                        this.projection.inverse(coordChange.apply(new Point(j,
                                i)))).normalized();

                double a = this.direction.scalarProduct(normal);

                b.setRGB(j, i,
                        Color.rgb((1d / 2d) * (a + 1d), (1d / 2d) * (a + 1d),
                                (1d / 2d) * (0.7d * a + 1d)).awtColor()
                                .getRGB());
            }
        }

        return b;
    }

    /**
     * Le noyau
     * 
     * @param rayon
     *            Le rayon
     * @return Le noyau sous forme d'un tableau
     */
    private float[] getKernel(double rayon) {
        double phi = rayon / 3d;
        int n = (int) (2 * Math.ceil(rayon) + 1);
        float[] noyau = new float[n];
        n = (n - 1) / 2;
        float total = 0;
        for (int i = 0; i < noyau.length; ++i) {
            noyau[i] = (float) Math.exp(-1f * Math.pow(i-n, 2)
                    / (2f * Math.pow(phi, 2)));
            total += noyau[i];
        }
        for (int i = 0; i < noyau.length; i++) {
            noyau[i] = noyau[i] / total;
        }
        return noyau;
    }

    /**
     * 
     * @param image
     *            Image
     * @param noyau
     *            Noyeau
     * @return Image floutee
     */
    private BufferedImage blur(BufferedImage image, float[] noyau) {

        Kernel k = new Kernel(1, noyau.length, noyau);
        ConvolveOp cop = new ConvolveOp(k, ConvolveOp.EDGE_NO_OP, null);
        image = cop.filter(image, null);

        k = new Kernel(noyau.length, 1, noyau);
        cop = new ConvolveOp(k, ConvolveOp.EDGE_NO_OP, null);
        return cop.filter(image, null);
    }
}
