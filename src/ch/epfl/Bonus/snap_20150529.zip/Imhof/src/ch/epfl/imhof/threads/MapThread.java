package ch.epfl.imhof.threads;

import java.io.IOException;

import org.xml.sax.SAXException;

import ch.epfl.imhof.Main;
import ch.epfl.imhof.Map;
import ch.epfl.imhof.SwissPainter;
import ch.epfl.imhof.duck.DuckReader;
import ch.epfl.imhof.geometry.Point;
import ch.epfl.imhof.osm.OSMMapReader;
import ch.epfl.imhof.osm.OSMToGeoTransformer;
import ch.epfl.imhof.painting.Color;
import ch.epfl.imhof.painting.Java2DCanvas;
import ch.epfl.imhof.projection.Projection;

public final class MapThread implements Runnable {
    private final Projection p;
    private final String pathOSMFile;
    private final Point bl, tr;
    private final int w, h, dpi;
    private final boolean duck;

    public MapThread(Projection p, String pathOSMFile, Point bl, Point tr,
            int w, int h, int dpi, boolean duck) {
        this.p = p;
        this.pathOSMFile = pathOSMFile;
        this.bl = bl;
        this.tr = tr;
        this.w = w;
        this.h = h;
        this.dpi = dpi;
        this.duck = duck;
    }

    @Override
    public void run() {
        try {
            // Generation de la carte
            Map map = null;
            if (!duck) {
                try {
                    map = new OSMToGeoTransformer(p).transform(OSMMapReader
                            .readOSMFile(pathOSMFile, true));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    map = DuckReader.readOSMFile(pathOSMFile, false);
                } catch (IOException | SAXException e) {
                    e.printStackTrace();
                }
            }

            // Generation de la toile
            Java2DCanvas canvas = new Java2DCanvas(bl, tr, w, h, dpi,
                    Color.WHITE);

            // Dessin de la carte et stockage
            SwissPainter.painter().drawMap(map, canvas);
            Main.setPlan(canvas.image());

            Thread.sleep(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
