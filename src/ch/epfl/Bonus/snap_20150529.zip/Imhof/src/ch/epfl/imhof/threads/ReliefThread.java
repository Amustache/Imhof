package ch.epfl.imhof.threads;

import java.io.File;

import ch.epfl.imhof.Main;
import ch.epfl.imhof.Vector3;
import ch.epfl.imhof.dem.HGTDigitalElevationModel;
import ch.epfl.imhof.dem.ReliefShader;
import ch.epfl.imhof.geometry.Point;
import ch.epfl.imhof.projection.Projection;

public final class ReliefThread implements Runnable {
    private final Projection p;
    private final String pathHGTFile;
    private final Point bl, tr;
    private final int w, h, dpi;

    public ReliefThread(Projection p, String pathHGTFile, Point bl, Point tr,
            int w, int h, int dpi) {
        this.p = p;
        this.pathHGTFile = pathHGTFile;
        this.bl = bl;
        this.tr = tr;
        this.w = w;
        this.h = h;
        this.dpi = dpi;
    }

    @Override
    public void run() {
        try {
            // Generation du relief
            HGTDigitalElevationModel dem = new HGTDigitalElevationModel(
                    new File(pathHGTFile));
            ReliefShader rs = new ReliefShader(p, dem, new Vector3(-1, 1, 1));

            // Dessin du relief et stockage
            Main.setRelief(rs.shadedRelief(bl, tr, w, h, dpi * (0.17d / 2.54d)));

            Thread.sleep(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
