package ch.epfl.imhof;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Table associative d'un ensemble d'attributs et de leurs clés.
 * 
 * @author Hugo Hueber (246095)
 * @author Maxime Pisa (247650)
 *
 */
public final class Attributes {
    private final Map<String, String> attributes;

    public Attributes(Map<String, String> attributes) {
        this.attributes = Collections
                .unmodifiableMap(new HashMap<String, String>(attributes));
    }

    public boolean isEmpty() {
        if (this.attributes.isEmpty() || this.attributes == null) {
            return true;
        } else {
            return false;
        }
    }

    public boolean contains(String key) {
        return this.attributes.containsKey(key);
    }

    public String get(String key) {
        return attributes.get(key);
    }

    public String get(String key, String defaultValue) {
        if (this.attributes.containsKey(key)) {
            return attributes.get(key);
        } else {
            return defaultValue;
        }
    }

    public int get(String key, int defaultValue) {
        if (this.attributes.containsKey(key)) {
            int retour;
            try {
                retour = Integer.parseInt(this.attributes.get(key));
            } catch (NumberFormatException e) {
                return defaultValue;
            }
            return retour;
        } else {
            return defaultValue;
        }
    }

    public Attributes keepOnlyKeys(Set<String> keysToKeep) {
        Attributes.Builder b = new Attributes.Builder();

        for (String key : keysToKeep) {
            if (this.attributes.containsKey(key)) {
                b.put(key, this.attributes.get(key));
            }
        }

        return b.build();

        // HashMap<String, String> newAttributes = new HashMap<String,
        // String>();
        //
        // for (String key : keysToKeep) {
        // if(this.attributes.containsKey(key)) {
        // newAttributes.put(key, this.attributes.get(key));
        // }
        // }
        //
        // return new Attributes(newAttributes);
    }

    public static final class Builder {
        HashMap<String, String> keys = new HashMap<String, String>();

        public void put(String key, String value) {
            this.keys.put(key, value);
        }

        public Attributes build() {
            final Attributes newAttributes = new Attributes(keys);
            return newAttributes;
        }
    }
}
