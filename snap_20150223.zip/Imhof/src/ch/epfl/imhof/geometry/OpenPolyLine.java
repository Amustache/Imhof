package ch.epfl.imhof.geometry;

import java.util.ArrayList;
import java.util.List;

/**
 * Polyline ouverte
 * @author Hugo Hueber (246095)
 * @author Maxime Pisa (247650)
 *
 */
public final class OpenPolyLine extends PolyLine {
    /**
     * @param points
     *      constructeur d une OpenPolyLine
     */
    public OpenPolyLine(List<Point> points) {
        super(new ArrayList<>(points));
    }
    
    /*
     * @return false
     *      OpenPolyLine n est jamais fermee
     */
    @Override
    boolean isClosed() {
        return false;
    }
}
