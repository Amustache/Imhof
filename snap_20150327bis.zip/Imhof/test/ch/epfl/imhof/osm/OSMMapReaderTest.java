package ch.epfl.imhof.osm;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.HashMap;

import org.junit.Test;
import org.xml.sax.SAXException;

import ch.epfl.imhof.Attributes;
import ch.epfl.imhof.PointGeo;

public class OSMMapReaderTest {
    @Test
    public void readOSMFileNoGZip() {
        OSMMap map = OSMMapReader.readOSMFile("bc.osm", false);
        
        Attributes attributes = new Attributes(new HashMap<String, String>());
        
        OSMNode node2 = new OSMNode(1, new PointGeo(6.5616727, 46.5182404), attributes);
        OSMNode node3 = new OSMNode(2, new PointGeo(6.5616658, 46.5188218), attributes);
        OSMNode node4 = new OSMNode(3, new PointGeo(6.5621886, 46.5188294), attributes);
        OSMNode node5 = new OSMNode(4, new PointGeo(6.5621964, 46.5182432), attributes);
        
        assertEquals(map.ways().get(0).nodesCount(), 4);
        assertEquals(map.ways().get(0).id(), 1);
        assertEquals(map.ways().get(0).firstNode().id(), 1);
    }
    
    @Test(expected = IOException.class)
    public void noSuchFile() {
        OSMMap map = OSMMapReader.readOSMFile("void.osm", false);
    }
    
    @Test(expected = SAXException.class)
    public void corruptedFile() {
        OSMMap map = OSMMapReader.readOSMFile("bc_corrupted.osm", false);
    }
}
