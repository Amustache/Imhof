package ch.epfl.imhof.osm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import ch.epfl.imhof.Attributes;
import ch.epfl.imhof.PointGeo;
import ch.epfl.imhof.osm.OSMRelation.Member;

public class OSMMapTest {
    @Test
    public void constructor() {
        ArrayList<OSMWay> ways = new ArrayList<OSMWay>();
        ArrayList<OSMRelation> relations = new ArrayList<OSMRelation>();
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(new HashMap<String, String>());
        
        for (int i = 0; i < 5; ++i) {
            nodes.add(new OSMNode(i, new PointGeo(0, 0), attributes));
        }
        for (int i = 0; i < 5; ++i) {
            ways.add(new OSMWay(i, nodes, attributes));
        }
        for (int i = 0; i < 5; ++i) {
            relations.add(new OSMRelation(i, new ArrayList<Member>(), attributes));
        }
        
        OSMMap map  = new OSMMap(ways, relations);
        
        assertEquals(map.ways(), ways);
        assertEquals(map.relations(), relations);
    }
    
    @Test(expected = UnsupportedOperationException.class)
    public void unmodifiable() {
        ArrayList<OSMWay> ways = new ArrayList<OSMWay>();
        ArrayList<OSMRelation> relations = new ArrayList<OSMRelation>();
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(new HashMap<String, String>());
        
        for (int i = 0; i < 5; ++i) {
            nodes.add(new OSMNode(i, new PointGeo(0, 0), attributes));
        }
        for (int i = 0; i < 5; ++i) {
            ways.add(new OSMWay(i, nodes, attributes));
        }
        for (int i = 0; i < 5; ++i) {
            relations.add(new OSMRelation(i, new ArrayList<Member>(), attributes));
        }
        
        OSMMap map  = new OSMMap(ways, relations);
        
        map.ways().add(new OSMWay(0, nodes, attributes));
        map.relations().clear();
    }
    
    @Test
    public void builder() {
        ArrayList<OSMWay> ways = new ArrayList<OSMWay>();
        ArrayList<OSMRelation> relations = new ArrayList<OSMRelation>();
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(new HashMap<String, String>());
        
        for (int i = 0; i < 5; ++i) {
            nodes.add(new OSMNode(i, new PointGeo(0, 0), attributes));
        }
        for (int i = 0; i < 5; ++i) {
            ways.add(new OSMWay(i, nodes, attributes));
        }
        for (int i = 0; i < 5; ++i) {
            relations.add(new OSMRelation(i, new ArrayList<Member>(), attributes));
        }
        
        OSMMap map  = new OSMMap(ways, relations);
        
        OSMMap.Builder builder = new OSMMap.Builder();
        for (int i = 0; i < 5; ++i) {
            builder.addNode(nodes.get(i));
        }
        assertEquals(builder.nodeForId(0), nodes.get(0));
        assertNull(builder.nodeForId(99));
        
        for (int i = 0; i < 5; ++i) {
            builder.addWay(ways.get(i));
        }
        assertEquals(builder.wayForId(1), ways.get(1));
        assertNull(builder.wayForId(98));
        
        for (int i = 0; i < 5; ++i) {
            builder.addRelation(relations.get(i));
        }
        assertEquals(builder.relationForId(2), relations.get(2));
        assertNull(builder.relationForId(97));
    }
}
