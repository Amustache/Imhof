/*
 *      Author:      Pisa Maxime
 *      Date:        8 mars 2015
 */
 
package ch.epfl.imhof.osm;
 
import static org.junit.Assert.*;
 
import java.util.ArrayList;
import java.util.HashMap;
 
import org.junit.Ignore;
import org.junit.Test;
 
import ch.epfl.imhof.Attributed;
import ch.epfl.imhof.Attributes;
import ch.epfl.imhof.PointGeo;
import ch.epfl.imhof.osm.OSMRelation.Member;
import ch.epfl.imhof.osm.OSMRelation.Member.Type;
 
/**
 * 
 * @author Hugo Hueber (246095)
 * @author Maxime Pisa (247650)
 *
 */
public class OSMRelationTest {
   
   
    @Test
    public void testConstructeurMember(){
       
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
       
        long id = 42;
        Attributes attributes = new Attributes(test);
        PointGeo position = new PointGeo(0, 0);
       
        OSMNode node = new OSMNode(id, position, attributes);
        Type NODE = null;
        Member m = new Member(NODE, "node", node);
    }
   
    @Test
    public void testMemberType(){
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
       
        long id = 42;
        Attributes attributes = new Attributes(test);
        PointGeo position = new PointGeo(0, 0);
       
        OSMNode node = new OSMNode(id, position, attributes);
        Type NODE = null;
        Member m = new Member(NODE, "node", node);
       
        assertEquals(NODE, m.type());
    }
   
    @Test
    public void testMemberRole(){
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
       
        long id = 42;
        Attributes attributes = new Attributes(test);
        PointGeo position = new PointGeo(0, 0);
       
        OSMNode node = new OSMNode(id, position, attributes);
        Type NODE = null;
        Member m = new Member(NODE, "node", node);
       
        assertEquals("node", m.role());
    }
   
    @Test
    public void testMemberMember(){
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
       
        long id = 42;
        Attributes attributes = new Attributes(test);
        PointGeo position = new PointGeo(0, 0);
       
        OSMNode node = new OSMNode(id, position, attributes);
        Type NODE = null;
        Member m = new Member(NODE, "node", node);
       
        assertEquals(node, m.member());
    }
 
    @Test
    public void testConstructeurRelation() {
       
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
       
        long id = 42;
        Attributes attributes = new Attributes(test);
        PointGeo position = new PointGeo(0, 0);
       
        OSMNode node = new OSMNode(id, position, attributes);
        Type NODE = null;
        Member m = new Member(NODE, "node", node);
       
        ArrayList<Member> members = new ArrayList<Member>();
        members.add(m);
 
        OSMRelation r = new OSMRelation(id, members, attributes);
    }
   
    @Test
    public void testRelationMembers() {
       
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
       
        long id = 42;
        Attributes attributes = new Attributes(test);
        PointGeo position = new PointGeo(0, 0);
       
        OSMNode node = new OSMNode(id, position, attributes);
        Type NODE = null;
        Member m = new Member(NODE, "node", node);
       
        ArrayList<Member> members = new ArrayList<Member>();
        members.add(m);
 
        OSMRelation r = new OSMRelation(id, members, attributes);
       
        assertEquals(members, r.members());
    }
   
    @Test
    public void testRelationBuilder() {
       
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
       
        long id = 42;
        Attributes attributes = new Attributes(test);
        PointGeo position = new PointGeo(0, 0);
       
        OSMNode node = new OSMNode(id, position, attributes);
        Type NODE = null;
        Member m = new Member(NODE, "node", node);
       
        ArrayList<Member> members = new ArrayList<Member>();
        members.add(m);
 
        OSMRelation r = new OSMRelation(id, members, attributes);
       
        OSMRelation.Builder b = new OSMRelation.Builder(42);
       
        b.addMember(NODE, "node", node);
        OSMRelation r1 = b.build();
       
        assertEquals(r.members().get(0).role(), r1.members().get(0).role());
        assertEquals(r.members().get(0).type(), r1.members().get(0).type());
        assertEquals(r.members().get(0).member().id(), r1.members().get(0).member().id());
        assertEquals(r.members().get(0).member().attributes(), r1.members().get(0).member().attributes());
 
    }
 
}