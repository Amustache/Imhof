package ch.epfl.imhof.geometry;

/**
 * Point en coordonnees carthesiennes
 * 
 * @author Hugo Hueber (246095)
 * @author Maxime Pisa (247650)
 *
 */
public final class Point {
    private final double x;
    private final double y;

    /**
     * Constructeur
     * 
     * @param x
     *            La coordonnee sur l'axe des abscisses
     * @param y
     *            La coordonnee sur l'axe des ordonnees
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double x() {
        return x;
    }

    public double y() {
        return y;
    }
}
