package ch.epfl.imhof;
 
import static org.junit.Assert.*;
 
import java.util.HashMap;
 
import org.junit.Test;
 
public class AttributedTest {
   
    @Test
    public void testValue(){
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
        Attributes a = new Attributes(test);
        Attributed<String> ap = new Attributed<>("1", a);
       
        assertEquals("1", ap.value());
    }
   
    @Test
    public void testAttributes(){
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
        Attributes a = new Attributes(test);
        Attributed<String> ap = new Attributed<>("1", a);
       
        assertEquals("1", ap.value());
    }
   
    @Test
    public void testHasAttribute(){
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
        Attributes a = new Attributes(test);
        Attributed<String> ap = new Attributed<>("1", a);
       
        assertEquals(false, ap.hasAttribute("existePas"));
        assertEquals(true, ap.hasAttribute("test"));
    }
   
    @Test
    public void testAttributeValue(){
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
        Attributes a = new Attributes(test);
        Attributed<String> ap = new Attributed<>("1", a);
       
        assertEquals("1", ap.attributeValue("test"));
        assertEquals(null, ap.attributeValue("existePas"));
    }
   
    @Test
    public void testAttributeValueDefault(){
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
        Attributes a = new Attributes(test);
        Attributed<String> ap = new Attributed<>("1", a);
       
        assertEquals("1", ap.attributeValue("test", "default"));
        assertEquals("default", ap.attributeValue("faux", "default"));
    }
   
    @Test
    public void testAttributeValueInt(){
        HashMap<String, String> test = new HashMap<String, String>();
        test.put("test", "1");
        Attributes a = new Attributes(test);
        Attributed<String> ap = new Attributed<>("1", a);
       
        assertEquals(1, ap.attributeValue("test", 10));
        //doit retourner 1
        assertEquals(1, ap.attributeValue("faux", 1));
       
        HashMap<String, String> test1 = new HashMap<String, String>();
        test.put("dada", "test");
        Attributes a1 = new Attributes(test);
        Attributed<String> ap1 = new Attributed<>("1", a);
       
        assertEquals(1, ap1.attributeValue("test1", 1));
    }
}