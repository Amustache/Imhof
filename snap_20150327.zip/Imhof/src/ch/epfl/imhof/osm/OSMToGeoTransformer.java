package ch.epfl.imhof.osm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import ch.epfl.imhof.Attributed;
import ch.epfl.imhof.Attributes;
import ch.epfl.imhof.Graph;
import ch.epfl.imhof.Map;
import ch.epfl.imhof.geometry.ClosedPolyLine;
import ch.epfl.imhof.geometry.OpenPolyLine;
import ch.epfl.imhof.geometry.Point;
import ch.epfl.imhof.geometry.PolyLine;
import ch.epfl.imhof.geometry.Polygon;
import ch.epfl.imhof.osm.OSMRelation.Member;
import ch.epfl.imhof.projection.Projection;

/**
 * Convertisseur de donnees OSM en carte
 * 
 * @author Hugo Hueber (246095)
 * @author Maxime Pisa (247650)
 *
 */
public final class OSMToGeoTransformer {
    private final Projection projection;

    /**
     * Construit un convertisseur OSM en geometrie qui utilise la projection
     * donnee
     * 
     * @param projection
     *            Projection a utiliser
     */
    public OSMToGeoTransformer(Projection projection) {
        this.projection = projection;
    }

    /**
     * Convertit une map OSM en une carte geometrique projetee OSMWay.isClosed
     * => Polygon !OSMWay.isClosed => PolyLine
     * 
     * @param map
     *            La map OSM
     * @return La carte construite
     */
    public Map transform(OSMMap map) {

        Map.Builder mapBuilder = new Map.Builder();

        List<OSMWay> osmWayList = map.ways();
        List<OSMRelation> osmRelationList = map.relations();
        List<Attributed<Polygon>> attributedPolygonList;
        Attributes att;

        for (int i = 0; i < osmWayList.size(); ++i) {
            if (isPolygon(osmWayList.get(i))) {
                att = triAttributes(osmWayList.get(i).attributes(), "polygon");
                if (!att.isEmpty()) {
                    mapBuilder.addPolygon(wayToPolygon(osmWayList.get(i), att));
                    // System.out.println("added polygon from way in mapbuilder");
                }
            } else {
                att = triAttributes(osmWayList.get(i).attributes(), "polyline");
                if (!att.isEmpty()) {
                    mapBuilder
                            .addPolyLine(wayToPolyLine(osmWayList.get(i), att));
                    // System.out.println("added polyline in mapbuilder");
                }
            }
        }

        for (int i = 0; i < osmRelationList.size(); ++i) {
            att = triAttributes(osmRelationList.get(i).attributes(), "polygon");
            if (!att.isEmpty()) {
                attributedPolygonList = assemblePolygon(osmRelationList.get(i),
                        att);

                for (int j = 0; j < attributedPolygonList.size(); ++j) {
                    mapBuilder.addPolygon(attributedPolygonList.get(j));
                }
                //
                // System.out.println("added polygon from relation in mapbuilder");
                // ArrayList<String> keysToKeep = new
                // ArrayList<String>(Arrays.asList("building", "landuse",
                // "layer", "leisure", "natural",
                // "waterway"));
                //
                // for (int j = 0; j < keysToKeep.size(); ++j) {
                // if (att.get(keysToKeep.get(j), "caca") != "caca") {
                // System.out.println("key: "+ keysToKeep.get(j) + " value : " +
                // att.get(keysToKeep.get(j), "rien"));
                // }
                // }
            }
        }
        // System.out.println("returned map");
        return mapBuilder.build();
    }

    private boolean isPolygon(OSMWay way) {
        if (way.isClosed()) {
            if (way.hasAttribute("building") || way.hasAttribute("landuse")
                    || way.hasAttribute("man_made")
                    || way.hasAttribute("natural")
                    || way.hasAttribute("waterway")) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * Convertit une OSMWay en PolyLine
     * 
     * @param way
     *            L'OSMWay a convertir
     * @param attributes
     *            Les attributs associes
     * @return La PolyLine correspondante
     */
    private Attributed<PolyLine> wayToPolyLine(OSMWay way, Attributes attributes) {
        List<OSMNode> osmNodeList = way.nodes();
        ArrayList<Point> pointList = new ArrayList<Point>();

        for (int i = 0; i < osmNodeList.size(); ++i) {
            pointList.add(projection.project(osmNodeList.get(i).position()));
        }

        OpenPolyLine p = new OpenPolyLine(pointList);
        return new Attributed<PolyLine>(p, attributes);
    }

    /**
     * Convertit une OSMWay en Polygon
     * 
     * @param way
     *            L'OSMWay a convertir
     * @param attributes
     *            Les attributs associes
     * @return Le Polygon correspondant
     */
    private Attributed<Polygon> wayToPolygon(OSMWay way, Attributes attributes) {
        List<OSMNode> osmNodeList = way.nodes();
        ArrayList<Point> pointList = new ArrayList<Point>();

        for (int i = 0; i < osmNodeList.size(); ++i) {
            pointList.add(projection.project(osmNodeList.get(i).position()));
        }

        ClosedPolyLine p = new ClosedPolyLine(pointList);
        Polygon polygon = new Polygon(p);

        return new Attributed<Polygon>(polygon, attributes);
    }

    /**
     * Tri les attributs en fonction d'un choix
     * 
     * @param attributes
     *            Les attributs a trier
     * @param choice
     *            Le choix
     * @return Les attributs tries
     */
    private Attributes triAttributes(Attributes attributes, String choice) {
        HashSet<String> keysToKeep;
        Attributes att = null;

        switch (choice) {
        case "polyline":
            keysToKeep = new HashSet<String>(Arrays.asList("bridge", "highway",
                    "layer", "man_made", "railway", "tunnel", "waterway"));
            att = attributes.keepOnlyKeys(keysToKeep);

            break;

        case "polygon":
            keysToKeep = new HashSet<String>(Arrays.asList("building",
                    "landuse", "layer", "leisure", "natural", "waterway"));
            att = attributes.keepOnlyKeys(keysToKeep);

            break;

        default:
            break;
        }
        return att;
    }

    /**
     * Calcule et retourne l'ensemble des anneaux de la relation donnee ayant le
     * role specifie
     * 
     * @param relation
     *            La relation a analyser
     * @param role
     *            Le role choisi (inner/outer)
     * @return La liste des ClosedPolylines
     */
    private List<ClosedPolyLine> ringsForRole(OSMRelation relation, String role) {
        Graph.Builder<OSMNode> graphBuilder = new Graph.Builder<OSMNode>();

        List<OSMWay> ways = new ArrayList<OSMWay>();

        // On trie les OSMWay avec le role demandé
        for (Member member : relation.members()) {
            if (member.type().equals(Member.Type.WAY)
                    && member.role().equals(role)) {
                ways.add((OSMWay) member.member());
            }
        }

        for (OSMWay osmWay : ways) {
            graphBuilder.addNode(osmWay.firstNode());
            for (int i = 1; i < osmWay.nodesCount(); ++i) {
                graphBuilder.addNode(osmWay.nodes().get(i));
                graphBuilder.addEdge(osmWay.nodes().get(i),
                        osmWay.nodes().get(i - 1));
            }
        }

        // On construit le graphe non oriente
        Graph<OSMNode> graph = graphBuilder.build();

        // Si un noeud n'a pas exactement 2 voisins, on retourne une liste vide
        for (OSMNode osmNode : graph.nodes()) {
            if (graph.neighborsOf(osmNode).size() != 2) {
                return new ArrayList<ClosedPolyLine>();
            }
        }

        // On construit un set avec les noeuds visites
        Set<OSMNode> nonVisited = new HashSet<OSMNode>(graph.nodes());

        // Liste des polylines
        List<ClosedPolyLine> polylines = new ArrayList<ClosedPolyLine>();

        // Iterateur sur les non visites
        // Iterator<OSMNode> iter = nonVisited.iterator(); << On ne peut pas
        // modifier une Collection lorsque celle-ci est traversee par un
        // Iterator

        // Tant qu'il reste un noeud non visite
        while (nonVisited.iterator().hasNext()) {
            // On prend un point, qui sera considere comme le debut d'un nouveau
            // noeud
            OSMNode first = nonVisited.iterator().next();

            // On cree une liste vide de points
            List<Point> points = new ArrayList<Point>();

            // On lance l'algorithme de creation de points
            createPoints(first, first, graph, nonVisited, points);

            // On ajoute la PolyLine correspondante a la liste des PolyLines
            polylines.add(new ClosedPolyLine(points));
        }

        return polylines;

    }

    /**
     * Permet de modifier une liste des points avec les points dans le bon ordre
     * 
     * @param first
     *            Le premier point de la Polyline
     * @param current
     *            Le point actuel traite
     * @param graph
     *            Le graph contenant les points/leurs voisins
     * @param nonVisited
     *            Le set des points non visites
     * @param points
     *            La liste a modifier
     */
    private void createPoints(OSMNode first, OSMNode current,
            Graph<OSMNode> graph, Set<OSMNode> nonVisited, List<Point> points) {

        // On fait la liste des voisins
        Iterator<OSMNode> iterNeigh = graph.neighborsOf(current).iterator();
        OSMNode neigh1 = iterNeigh.next();
        OSMNode neigh2 = iterNeigh.next();

        // Le point est desormais "visite"
        nonVisited.remove(current);

        // Si le set des points non visites ne contient aucun des voisins du
        // point actuel, c'est que l'on est retourne au debut de la polyline. On
        // ajoute ainsi de noueau le premier point, justement pour "ferme" la
        // polyline
        if (!nonVisited.contains(neigh1) && !nonVisited.contains(neigh2)) {

            // On ajoute le point final/premier a la liste des points
            points.add(projection.project(current.position()));
            points.add(projection.project(first.position()));

            return;
        } else { // Sinon, c'est qu'il y a au moins un voisin non visite

            // On ajoute le point actuel a la liste des points
            points.add(projection.project(current.position()));

            // Test des voisins
            current = nonVisited.contains(neigh1) ? neigh1 : neigh2;

            // Et on boucle...
            createPoints(first, current, graph, nonVisited, points);
            return;
        }
    }

    /**
     * Calcule et retourne la liste des polygones attribues de la relation
     * donnee, en leur attachant les attributs donnes.
     * 
     * @param relation
     *            La relation a analyser
     * @param attributes
     *            Les attributs a attacher
     * @return Une liste de Polygons avec leurs attributs
     */
    private List<Attributed<Polygon>> assemblePolygon(OSMRelation relation,
            Attributes attributes) {

        ArrayList<Attributed<Polygon>> attributedPolygon = new ArrayList<Attributed<Polygon>>();
        List<ClosedPolyLine> outers = this.ringsForRole(relation, "outer");
        List<ClosedPolyLine> inners = this.ringsForRole(relation, "inner");

        CompareClosedPolyLine c = new CompareClosedPolyLine();
        Collections.sort(outers, c);

        ArrayList<ClosedPolyLine> holes = new ArrayList<>();
        ArrayList<Polygon> polygon = new ArrayList<>();

        for (int i = 0; i < outers.size(); ++i) {
            for (int j = 0; j < inners.size(); ++j) {
                if (outers.get(i).containsPoint(inners.get(j).firstPoint())) {
                    holes.add(inners.get(j));
                    inners.remove(j);
                    j--;
                }
            }
            polygon.add(new Polygon(outers.get(i), holes));
            holes.clear();
        }

        for (int i = 0; i < polygon.size(); ++i) {
            attributedPolygon.add(new Attributed<Polygon>(polygon.get(i),
                    attributes));
        }
        return attributedPolygon;
    }

    private class CompareClosedPolyLine implements Comparator<ClosedPolyLine> {

        @Override
        public int compare(ClosedPolyLine o1, ClosedPolyLine o2) {
            if (o1.area() > o2.area()) {
                return 1;
            } else if (o1.area() < o2.area()) {
                return -1;
            } else {
                return 0;
            }
        }
    }
}
