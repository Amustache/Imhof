package ch.epfl.imhof.osm;

import ch.epfl.imhof.Attributes;
import ch.epfl.imhof.PointGeo;

/**
 * Represente un noeud OSM.
 * 
 * @author Hugo Hueber (246095)
 * @author Maxime Pisa (247650)
 *
 */
public final class OSMNode extends OSMEntity {

    private final PointGeo position;

    /**
     * @param id
     * @param position
     * @param attributes
     *
     *            construit un nœud OSM avec l'identifiant, la position et les
     *            attributs donnés
     */
    public OSMNode(long id, PointGeo position, Attributes attributes) {
        super(id, attributes);
        this.position = position;
    }

    /**
     * @return retourne la position du nœud
     */
    public PointGeo position() {
        return this.position;
    }

    public static final class Builder extends OSMEntity.Builder {

        private final PointGeo position;

        /**
         * @param id
         * @param position
         *
         *            construit un bâtisseur pour un nœud ayant l'identifiant et
         *            la position donnés
         */
        public Builder(long id, PointGeo position) {
            super(id);
            this.position = position;
        }

        /*
         * (non-Javadoc)
         * 
         * @see ch.epfl.imhof.osm.OSMEntity.Builder#build()
         * 
         * construit un nœud OSM avec l'identifiant et la position passés au
         * constructeur, et les éventuels attributs ajoutés jusqu'ici au
         * bâtisseur. Lève l'exception IllegalStateException si le nœud en cours
         * de construction est incomplet, c-à-d si la méthode setIncomplete a
         * été appelée sur ce bâtisseur depuis sa création
         */
        public OSMNode build() throws IllegalStateException {
            if (this.isIncomplete()) {
                throw new IllegalStateException("node is incomplete");
            } else {
                return new OSMNode(this.getId(), this.position, this
                        .getBuilder().build());
            }
        }
    }
}