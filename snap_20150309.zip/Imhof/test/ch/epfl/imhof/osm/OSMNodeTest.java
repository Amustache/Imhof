package ch.epfl.imhof.osm;

import static org.junit.Assert.*;

import java.util.HashMap;

import org.junit.Test;

import ch.epfl.imhof.Attributes;
import ch.epfl.imhof.PointGeo;

/**
 * 
 * @author Hugo Hueber (246095)
 * @author Maxime Pisa (247650)
 *
 */
public class OSMNodeTest {
    @Test
    public void constructor() {
        PointGeo position = new PointGeo(0, 0);
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {
            a0.put("Key" + i, "Value" + i);
        }
        Attributes attributes = new Attributes(a0);
        OSMNode o0 = new OSMNode(1337, position, attributes);

        assertEquals(o0.id(), 1337);

        assertEquals(o0.attributes(), attributes);

        assertFalse(o0.hasAttribute("Nope"));

        for (int i = 0; i < 5; i++) {
            assertTrue(o0.hasAttribute("Key" + i));
        }

        for (int i = 0; i < 5; ++i) {
            assertEquals(o0.attributeValue("Key" + i), "Value" + i);
        }

        assertEquals(o0.position(), position);
    }

    @Test
    public void builder() {
        PointGeo position = new PointGeo(0, 0);
        OSMNode.Builder builder = new OSMNode.Builder(1338, position);

        for (int i = 0; i < 5; ++i) {
            builder.setAttribute("Key" + i, "Value" + i);
        }

        OSMNode o1 = builder.build();

        assertEquals(o1.id(), 1338);

        assertEquals(o1.position(), position);

        for (int i = 0; i < 5; ++i) {
            assertEquals(o1.attributeValue("Key" + i), "Value" + i);
        }
    }

    @Test(expected = IllegalStateException.class)
    public void isIncomplete() {
        PointGeo position = new PointGeo(0, 0);
        OSMNode.Builder builder = new OSMNode.Builder(1338, position);
        builder.setIncomplete();
        @SuppressWarnings("unused")
        OSMNode o2 = builder.build();
    }
}
