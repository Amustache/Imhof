package ch.epfl.imhof.osm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import ch.epfl.imhof.Attributes;
import ch.epfl.imhof.PointGeo;

/**
 * 
 * @author Hugo Hueber (246095)
 * @author Maxime Pisa (247650)
 *
 */
public class OSMWayTest {
    @Test
    public void constructor() {
        PointGeo position = new PointGeo(0, 0);
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a0.put("Key" + i, "Value" + i);}
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(a0);
        nodes.add(new OSMNode(1, position, attributes));
        nodes.add(new OSMNode(2, position, attributes));
        nodes.add(new OSMNode(3, position, attributes));
        OSMWay o0 = new OSMWay(1337, nodes, attributes);
        
        assertEquals(o0.id(), 1337);
        
        assertEquals(o0.attributes(), attributes);
        
        assertFalse(o0.hasAttribute("Nope"));
        
        for (int i = 0; i < 5; i++) {assertTrue(o0.hasAttribute("Key" + i));}
        
        for (int i = 0; i < 5; ++i) {assertEquals(o0.attributeValue("Key" + i), "Value" + i);}
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void lessThanTwoNodes() {
        PointGeo position = new PointGeo(0, 0);
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a0.put("Key" + i, "Value" + i);}
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(a0);
        nodes.add(new OSMNode(1, position, attributes));
        OSMWay o0 = new OSMWay(1337, nodes, attributes);
    }
    
    @Test
    public void nodesCount() {
        PointGeo position = new PointGeo(0, 0);
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a0.put("Key" + i, "Value" + i);}
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(a0);
        for (int i = 2; i < 10; i++) {
            nodes.add(new OSMNode(i, position, attributes));
        }
        OSMWay o0 = new OSMWay(1337, nodes, attributes);
        
        assertEquals(o0.nodesCount(), 8);
    }
    
    @Test
    public void nodes() {
        PointGeo position = new PointGeo(0, 0);
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a0.put("Key" + i, "Value" + i);}
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(a0);
        for (int i = 2; i < 10; i++) {
            nodes.add(new OSMNode(i, position, attributes));
        }
        OSMWay o0 = new OSMWay(1337, nodes, attributes);
        
        assertEquals(o0.nodes(), nodes);
    }
    
    @Test
    public void nonRepeatingNodes() {
        PointGeo position = new PointGeo(0, 0);
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a0.put("Key" + i, "Value" + i);}
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(a0);
        
        OSMNode same = new OSMNode(0, position, attributes);
        nodes.add(same);
        nodes.add(same);
        nodes.add(same);
        
        ArrayList<OSMNode> nodesTest = new ArrayList<OSMNode>();
        nodesTest.add(same);
        nodesTest.add(same);
        
        OSMWay o0 = new OSMWay(1337, nodes, attributes);
        
        assertEquals(o0.nonRepeatingNodes(), nodesTest);
        
        OSMNode different = new OSMNode(13, position, attributes);
        nodes.add(different);
        
        nodesTest.add(same);nodesTest.add(different);
        
        OSMWay o1 = new OSMWay(1337, nodes, attributes);
        
        assertEquals(o1.nonRepeatingNodes(), nodesTest);
    }
    
    @Test
    public void firstNodeAndLastNode() {
        PointGeo position = new PointGeo(0, 0);
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a0.put("Key" + i, "Value" + i);}
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(a0);
        for (int i = 2; i < 10; i++) {
            nodes.add(new OSMNode(i, position, attributes));
        }
        OSMWay o0 = new OSMWay(1337, nodes, attributes);
        
        assertEquals(o0.firstNode(), nodes.get(0));
        assertEquals(o0.lastNode(), nodes.get(7));
    }
    
    @Test
    public void isClosed() {
        PointGeo position = new PointGeo(0, 0);
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a0.put("Key" + i, "Value" + i);}
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(a0);
        
        OSMNode same = new OSMNode(0, position, attributes);
        nodes.add(same);
        nodes.add(same);
        nodes.add(same);
        
        OSMWay o0 = new OSMWay(1337, nodes, attributes);
        
        assertTrue(o0.isClosed());
        
        OSMNode different = new OSMNode(13, position, attributes);
        nodes.add(different);
        OSMWay o1 = new OSMWay(1337, nodes, attributes);
        
        assertFalse(o1.isClosed());
    }
    
    @Test
    public void builder() {
        OSMWay.Builder builder = new OSMWay.Builder(785);
        
        PointGeo position = new PointGeo(0, 0);
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a0.put("Key" + i, "Value" + i);}
        ArrayList<OSMNode> nodes = new ArrayList<OSMNode>();
        Attributes attributes = new Attributes(a0);
        OSMNode un = new OSMNode(1, position, attributes);
        OSMNode deux = new OSMNode(2, position, attributes);
        OSMNode trois = new OSMNode(3, position, attributes);
        
        nodes.add(un);
        nodes.add(deux);
        nodes.add(trois);
        OSMWay o0 = new OSMWay(785, nodes, attributes);
        
        builder.addNode(un);
        builder.addNode(deux);
        builder.addNode(trois);
        
        for (int i = 0; i < 5; ++i) {builder.setAttribute("Key" + i, "Value" + i);}
        
        assertEquals(builder.getId(), o0.id());
        
        OSMWay o1 = builder.build();
        
        assertEquals(o0.firstNode(), o1.firstNode());
        assertEquals(o0.id(), o1.id());
        assertEquals(o0.nonRepeatingNodes(), o1.nonRepeatingNodes());
    }
}
