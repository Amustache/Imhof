package ch.epfl.imhof;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.HashSet;

import org.junit.Test;

public class AttributesTest {
    
    @Test
    public void constructor() {
        HashMap<String, String> a0 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a0.put("Key" + i, "Value" + i);}
        Attributes test0 = new Attributes(a0);
        
        for (int i = 0; i < 5; ++i) {assertEquals(test0.get("Key" + i), "Value" + i);}
        
        a0.clear();
        for (int i = 0; i < 5; ++i) {assertEquals(test0.get("Key" + i), "Value" + i);}
    }
    
    @Test
    public void isEmpty() {
        HashMap<String, String> a1 = new HashMap<>();
        Attributes test1 = new Attributes(a1);
        assertTrue(test1.isEmpty());
        
        a1.put("cle", "value");
        Attributes test2 = new Attributes(a1);
        assertFalse(test2.isEmpty());
    }
    
    @Test
    public void contains() {
        HashMap<String, String> a2 = new HashMap<>();
        a2.put("key", "value");
        Attributes test3 = new Attributes(a2);
        
        assertFalse(test3.contains("totallyNotKey"));
        assertTrue(test3.contains("key"));
    }
    
    @Test
    public void get() {
        HashMap<String, String> a3 = new HashMap<>();
        a3.put("One", "Qwerty");
        a3.put("Two", "1337");
        Attributes test4 = new Attributes(a3);
        
        assertNull(test4.get("Neo"));
        assertEquals(test4.get("One"), "Qwerty");
        assertEquals(test4.get("Neo", "<void>"), "<void>");
        assertEquals(test4.get("Two", 13), 1337);
        assertEquals(test4.get("Wot", 13), 13);
    }
    
    @Test
    public void keepOnlyKeys() {
        HashMap<String, String> a4 = new HashMap<>();
        for (int i = 0; i < 5; ++i) {a4.put("Key" + i, "Value" + i);}
        Attributes test5 = new Attributes(a4);
        
        HashSet<String> keysToKeep = new HashSet<>();
        keysToKeep.add("Key0"); keysToKeep.add("Key2"); keysToKeep.add("Key4");
        Attributes test5sub = test5.keepOnlyKeys(keysToKeep);
        
        String test = "";
        for (int i = 0; i < 5; ++i) {
            test += test5sub.get("Key" + i, "Nope") + ",";
        }
        
        assertEquals("Value0,Nope,Value2,Nope,Value4,", test);
    }
}
